jQuery(function ($) {
    $('#btnLoginUser').click(function(e) {
        e.preventDefault();
        console.log('enter submit');
        var failure = function(err) {
           console.log("Unable to retrive data " + err);
        };


        var signon = $('#username').val();
        var password = $('#password').val();
        var logindata = {"SignOn":"test776@mcafee.com","Password":"Mcafee123","ApplicationCode":"HOME-41174094D71648BD8AA7BD0C670B15B4","RequestedBy":"AuthServer"};

        if (!signon || !password ) {
          console.log("error");
            // errormessage('Email and Password is required ');
            return;
        }

       
        $.ajax({
            type: 'POST',
            url: 'https://httpbin.org/post',
            headers: {
               'Content-Type': 'application/json',
               'ApplicationKey': 'HOME-41174094D71648BD8AA7BD0C670B15B4',
               'SharedKey': 'B82OWjuWML7qP7W+P2yeFOR0cB6BXSFf2E9PGn1/avE',


            },  
            data: logindata,
            success: function(msg) {

                  console.log("Success"+"MSG==="+msg);

            },
            error: function(jqXHR, textStatus, message) {
                
                var response = $.parseHTML(jqXHR.responseText);
                if (jqXHR.status == 400) {
                   
                   // var x = document.getElementById("changer");
                   // if (x.style.display === "none") {
                   //     x.style.display = "block";
                   // }
                   // $("#changer").html($(response).filter('h1').text());

                }
            }
        });
    });
});