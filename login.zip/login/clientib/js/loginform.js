jQuery(function ($) {
    $('#btnLoginUser').click(function() {
        console.log('enter submit');
        var failure = function(err) {
           // alert("Unable to retrive data " + err);
        };


        var signon = $('#txtUserName').val();
        var password = $('#txtPassword').val();
        var logindata = {"SignOn":"test776@mcafee.com","Password":"Mcafee123","ApplicationCode":"HOME-41174094D71648BD8AA7BD0C670B15B4","RequestedBy":"AuthServer"};

        if (!signon || !password ) {
          
            // errormessage('Email and Password is required ');
            return;
        }

       
        $.ajax({
            type: 'POST',
            url: 'https://auth.int.mcafee.com/api/OAuth2/Auth/AuthenticateUser/',
            headers: {
               'Content-Type': 'application/json',
               'ApplicationKey': 'HOME-41174094D71648BD8AA7BD0C670B15B4',
               'SharedKey': 'B82OWjuWML7qP7W+P2yeFOR0cB6BXSFf2E9PGn1/avE',
               'Access-Control-Request-Headers': 'x-requested-with'

            },  
            data: logindata,
            success: function(msg) {

                  // alert("Success");

            },
            error: function(jqXHR, textStatus, message) {
                
                var response = $.parseHTML(jqXHR.responseText);
                if (jqXHR.status == 400) {
                   
                   // var x = document.getElementById("changer");
                   // if (x.style.display === "none") {
                   //     x.style.display = "block";
                   // }
                   // $("#changer").html($(response).filter('h1').text());

                }
            }
        });
    });
});